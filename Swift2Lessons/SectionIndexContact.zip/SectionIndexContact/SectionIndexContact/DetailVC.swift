//
//  DetailVC.swift
//  SectionIndexContact
//
//  Created by hoangdangtrung on 1/15/16.
//  Copyright © 2016 hoangdangtrung. All rights reserved.
//

import UIKit

class DetailVC: UIViewController {
    var person = Person()
    
    var labelName = UILabel()
    var labelMobileBlue = UILabel()
    var labelPhoneNumber = UILabel()
    var imagePhone = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = UIColor.whiteColor()
        
        self.labelName.frame = CGRectMake(30, 100, 300, 50)
        self.labelName.font = UIFont.boldSystemFontOfSize(25)
        
        
        self.labelMobileBlue.frame = CGRectMake(30, 200, 100, 30)
        self.labelMobileBlue.text = "mobile"
        self.labelMobileBlue.textColor = UIColor.blueColor()
        
        self.labelPhoneNumber.frame = CGRectMake(30, 220, 200, 30)
        
        self.imagePhone.image = UIImage(named: "phone")
        self.imagePhone.frame = CGRectMake(self.view.bounds.size.width - 100, 210, 79, 38)
        
        self.view.addSubview(self.labelName)
        self.view.addSubview(self.labelMobileBlue)
        self.view.addSubview(self.labelPhoneNumber)
        self.view.addSubview(self.imagePhone)
        
        self.setTextForLabelName(person.middleName + " " + person.firstName, phone: person.mobilePhone)
        
    }
    
    func setTextForLabelName(name: String, phone: String) {
        self.labelPhoneNumber.text = phone
        self.labelName.text = name

    }


}
