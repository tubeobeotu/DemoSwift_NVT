//
//  SectionIndexTableVC.swift
//  SectionIndexContact
//
//  Created by hoangdangtrung on 1/12/16.
//  Copyright © 2016 hoangdangtrung. All rights reserved.
//

import UIKit

class SectionIndex_TableVC: UITableViewController {
    var arrayData: NSMutableArray!
    var dictContact = NSMutableDictionary() // Dictionary dùng để lưu trữ các cặp key - value.
    var arrayKey: NSArray!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.sectionIndexBackgroundColor = UIColor.grayColor() /* Change Section Index Background Color */
        self.tableView.sectionIndexColor = UIColor.whiteColor() /* Change Section Index Color (A...B...C...) */
        self.tableView.sectionIndexTrackingBackgroundColor = UIColor.blackColor() /* Highlight Color when user tap to Section Index */
        
        arrayData = NSMutableArray()
        for i in 0...60 {
            arrayData.addObject(Person())
            let person = arrayData[i] as! Person
            print(person.fullName)
        }
        
        for element in arrayData { // Truy xuất lần lượt từng phần tử trong mảng arrayData
            let person: Person = element as! Person //
            var firstLetter: String = (person.firstName as NSString!).substringToIndex(1) // Khai báo 1 string và gán giá trị là kí tự đầu tiên trong string firstName
            if firstLetter == "Đ" {
                firstLetter = "D"
            }
            if firstLetter == "Á" {
                firstLetter = "A"
            }
            
            var arrayForLetter: NSMutableArray! // Khai báo mảng để chứa các đối tượng person có firstName tương ứng với firstLetter. Ví dụ firstLetter là chữ B, thì arrayForLetter sẽ chứa các đối tượng person có firstName bắt đầu = chữ B
            
            if (dictContact.valueForKey(firstLetter) != nil) { // Kiểm tra nếu value tương ứng với key trong dictContacts mà tồn tại giá trị thì...
                arrayForLetter = dictContact.valueForKey(firstLetter) as! NSMutableArray //Gán giá trị đó đến mảng arayForLetter
                arrayForLetter.addObject(person) //Sau đó add thêm đối tượng person đến arrayForLetter
                dictContact.setValue(arrayForLetter, forKey: firstLetter) //Rồi truyền ngược trở lại arrayForLetter đó đến value tương ứng với key trong dictContacts
            } else { // Trong trường hợp value tương ứng với key trong dictContacts mà bằng nil
                arrayForLetter = NSMutableArray(object: person) // Gán đối tượng person đến mảng arrayForLetter
                dictContact.setValue(arrayForLetter, forKey: firstLetter) // Sau đó set value cho dictContacts là arrayForLetter tương ứng với key là firstLetter
            }
            
        }
        
        print(dictContact)
        
        arrayKey = dictContact.allKeys as! [String] // Lấy ra mảng chứa tất cả các key trong dictContacts
        arrayKey = arrayKey.sortedArrayUsingSelector("compare:") // Sắp xếp theo AlphaBe
        
        //        self.tableView.registerClass(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        
    }
    
    // MARK: - Table view arrayData source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return arrayKey.count
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let sectionTitle = arrayKey[section]
        let sectionPersons = dictContact[sectionTitle as! String]
        
        return (sectionPersons?.count)!
    }
    
    override func tableView(tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return arrayKey[section] as? String
    }
    
    override func sectionIndexTitlesForTableView(tableView: UITableView) -> [String]? {
        return arrayKey as? [String]
    }
    
    override func tableView(tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        view.tintColor = UIColor.grayColor()
        let header: UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView
        header.textLabel?.textColor = UIColor.whiteColor()
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell = tableView.dequeueReusableCellWithIdentifier("Cell")
        if(cell == nil) {
            cell = UITableViewCell(style: UITableViewCellStyle.Subtitle, reuseIdentifier: "Cell")
        }
        let sectionTitle = arrayKey[indexPath.section]
        let sectionPersons = dictContact[sectionTitle as! String]
        
        let person = sectionPersons![indexPath.row] as! Person
        
        cell!.textLabel?.text = person.fullName
        cell!.detailTextLabel?.text = person.mobilePhone
        
        return cell!
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    //MARK - Table view delegate
    
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let detailVC = DetailVC()
        
        let sectionTitle = arrayKey[indexPath.section]
        let sectionPersons = dictContact[sectionTitle as! String]
        
        let person = sectionPersons![indexPath.row] as! Person
        
        detailVC.person = person
        
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
    
    
}









