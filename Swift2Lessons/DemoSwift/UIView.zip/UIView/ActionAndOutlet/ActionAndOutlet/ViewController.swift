//
//  ViewController.swift
//  ActionAndOutlet
//
//  Created by Tuuu on 5/18/16.
//  Copyright © 2016 TuNguyen. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    


}

